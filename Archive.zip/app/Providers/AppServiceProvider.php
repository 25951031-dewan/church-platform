<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use App\Modules\ModuleManager;
use App\Modules\Community\CommunityServiceProvider;
use App\Modules\Counseling\CounselingServiceProvider;
use App\Services\ChurchContext;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Singletons for church context and module management
        $this->app->singleton(ChurchContext::class);
        $this->app->singleton(ModuleManager::class);
    }

    public function boot(): void
    {
        Schema::defaultStringLength(191);

        // Register module service providers
        $this->app->register(CommunityServiceProvider::class);
        $this->app->register(CounselingServiceProvider::class);
    }
}
