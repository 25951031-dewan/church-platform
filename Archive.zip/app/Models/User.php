<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = [
        'name', 'email', 'password', 'is_admin', 'role_id', 'church_id',
        'avatar', 'bio', 'phone', 'church_name', 'social_id',
        'spiritual_background', 'custom_fields', 'profile_completed',
        'provider', 'provider_id',
    ];

    protected $hidden = ['password', 'remember_token'];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'is_admin' => 'boolean',
        'custom_fields' => 'array',
        'profile_completed' => 'boolean',
    ];

    public function role() { return $this->belongsTo(Role::class); }
    public function posts() { return $this->hasMany(Post::class, 'author_id'); }
    public function prayerRequests() { return $this->hasMany(PrayerRequest::class); }
    public function reviews() { return $this->hasMany(Review::class); }
    public function bibleStudies() { return $this->hasMany(BibleStudy::class, 'author_id'); }
    public function sermons() { return $this->hasMany(Sermon::class, 'author_id'); }
    public function church() { return $this->belongsTo(Church::class); }
    public function managedChurch() { return $this->hasOne(Church::class, 'admin_user_id'); }

    /**
     * Check if the user has a specific permission.
     * Result is cached per user for 5 minutes (file cache, shared-hosting friendly).
     */
    public function hasPermission(string $permission): bool
    {
        if ($this->is_admin) {
            return true;
        }

        $permissions = $this->getCachedPermissions();
        return in_array($permission, $permissions);
    }

    /**
     * Check if the user has a specific role by slug.
     */
    public function hasRole(string $slug): bool
    {
        if ($this->is_admin) {
            return true;
        }
        return $this->role && $this->role->slug === $slug;
    }

    /**
     * Get role level (higher = more permissions).
     */
    public function getRoleLevel(): int
    {
        if ($this->is_admin) {
            return 100;
        }
        return $this->role ? ($this->role->level ?? 10) : 0;
    }

    /**
     * Get this user's permissions from cache or DB.
     */
    public function getCachedPermissions(): array
    {
        return \Illuminate\Support\Facades\Cache::store('file')
            ->remember("user_{$this->id}_perms", 300, function () {
                if (!$this->relationLoaded('role')) {
                    $this->load('role');
                }
                return $this->role ? ($this->role->permissions ?? []) : [];
            });
    }

    /**
     * Clear the permission cache for this user (call after role change).
     */
    public function clearPermissionCache(): void
    {
        \Illuminate\Support\Facades\Cache::store('file')->forget("user_{$this->id}_perms");
    }

    /**
     * Churches this user belongs to (multi-church pivot).
     */
    public function churches()
    {
        return $this->belongsToMany(Church::class, 'church_user')
            ->withPivot('role', 'joined_at')
            ->withTimestamps();
    }
}
